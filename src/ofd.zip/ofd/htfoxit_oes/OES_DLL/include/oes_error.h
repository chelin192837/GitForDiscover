#ifndef __OFD_HTFOXIT_OES_ERROR_H_
#define __OFD_HTFOXIT_OES_ERROR_H_

extern std::string GetErrMsg(unsigned long errCode);

#endif//__OFD_HTFOXIT_OES_ERROR_H_