#include "../include/oes_base_lib.h"


OES_Base_Lib::OES_Base_Lib()
{
}
