#ifndef OES_BASE_LIB_H
#define OES_BASE_LIB_H


class OES_Base_Lib
{
public:
    OES_Base_Lib();
};

#endif // OES_BASE_LIB_H
